import pages.LoginPage;
import pages.StudentPage;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Show that I improved a part of this program hehe
        JOptionPane.showMessageDialog(null, "Villanueva, John Carlo T.", "BSIT 2-2", JOptionPane.INFORMATION_MESSAGE);
        
        // Please refer to the LoginPage.java for the full explanation.
        SwingUtilities.invokeLater(LoginPage::new);
    }
}