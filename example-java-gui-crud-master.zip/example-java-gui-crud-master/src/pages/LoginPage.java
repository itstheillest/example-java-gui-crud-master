package pages;

import dal.admins.AdminDAO;
import db.Database;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LoginPage extends JFrame {
    private final AdminDAO adminDao = new AdminDAO();
    private final JButton logInBtn;
    private final JButton signUpBtn;
    private final JTextField fieldUsername;
    private final JPasswordField fieldPassword;
    private final JLabel confirmPasswordLabel;
    private final JPasswordField repeatPasswordField;
    private boolean enter = false;

    public LoginPage() {
		setTitle("Admin Login");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
    	// Added a sign up page for signing up
        // First, I recreated the whole log in page in Eclipse and improved the design a little bit
        // Declare all of the JLabels, JTextFields, and the JPasswordField
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);
        
        
        // Declaration of labelUsername, setting it's bounds, and adding it to the main panel.
        JLabel labelUsername = new JLabel("Username: ");
        labelUsername.setBounds(10, 24, 101, 14);
        getContentPane().add(labelUsername);
        
        // Same concept for the rest
        JLabel labelPassword = new JLabel("Password: "); 
        labelPassword.setBounds(10, 49, 77, 14);
        getContentPane().add(labelPassword);
        
        fieldUsername = new JTextField();
        fieldUsername.setBounds(91, 21, 283, 20);
        getContentPane().add(fieldUsername);
        fieldUsername.setColumns(10);
        
        fieldPassword = new JPasswordField();
        fieldPassword.setBounds(91, 46, 283, 20);
        getContentPane().add(fieldPassword);
        fieldPassword.setColumns(10);
        
        logInBtn = new JButton("Log In");
        logInBtn.setBounds(118, 99, 89, 23);
        getContentPane().add(logInBtn);
        
        signUpBtn = new JButton("Sign Up");
        signUpBtn.setBounds(228, 99, 89, 23);
        getContentPane().add(signUpBtn);
        
        // Repeat password for an added security.
        confirmPasswordLabel = new JLabel("Repeat Password:");
        confirmPasswordLabel.setVisible(false);
        confirmPasswordLabel.setBounds(10, 74, 136, 14);
        getContentPane().add(confirmPasswordLabel);
        
        repeatPasswordField = new JPasswordField();
        repeatPasswordField.setVisible(false);
        repeatPasswordField.setBounds(118, 71, 256, 20);
        getContentPane().add(repeatPasswordField);
        repeatPasswordField.setColumns(10);
        
        setVisible(true);
        
        // I kept this stock. The same as how I downloaded it.
        logInBtn.addActionListener(e -> handleLogin());
        
        // The new feature, the ability to sign up.
        signUpBtn.addActionListener(e -> handleSignUp());    
    }

    private void handleLogin() {
    	
    	// Clear all text fields by default. 
    	fieldUsername.setText("");
        fieldPassword.setText("");
        repeatPasswordField.setText("");
        
        // repeat the cycle 
        enter = false;
           
    	// Set the repeat password field and label to invisible because it's unnecessary for logging in. 
    	confirmPasswordLabel.setVisible(false);
    	repeatPasswordField.setVisible(false);
    	
    	setTitle("Admin Login");
    	
        String username = fieldUsername.getText();
        String password = new String(fieldPassword.getPassword());

        // As you can see, there is an "enter = true" here. That is for the purpose of not showing JOptionPane when the 
        // Sign up button is clicked for the first time.
        // This is the same for later down the line.
        if (username.isEmpty() || password.isEmpty()) {
        	if(enter == true) {
        		JOptionPane.showMessageDialog(this, "Please enter both username and password.");
        	}
        	enter = true;
            return;   
        }

        boolean valid = adminDao.checkIfAdminExists(username, password);
        
        if (valid) {
            JOptionPane.showMessageDialog(this, "Login successful!");
            new StudentPage();

            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }
        
        
    }
    
    private void handleSignUp() {
    	
    	// Clear all text fields by default. 
    	fieldUsername.setText("");
        fieldPassword.setText("");
        repeatPasswordField.setText("");
        
     // repeat the cycle 
        enter = false;
    	
    	// I set the confirm password label and field to false by default, and made it so that it only shows...
    	// up when the sign up button is pressed.
    	confirmPasswordLabel.setVisible(true);
    	repeatPasswordField.setVisible(true);
    	setTitle("Admin Sign Up");

    	// This gets the text inputted in the password field
        String username = fieldUsername.getText();
        String password = new String(fieldPassword.getPassword());
        String passwordRepeat = new String(repeatPasswordField.getPassword());
    
        // If password is not the same as the password repeat, then return.
        // Same concept for the enter = true.
        if (!password.equals(passwordRepeat)) {
        	if(enter == true) {
            	JOptionPane.showMessageDialog(this, "Incorrect password.");
        	}
        	enter = true;
            return;
        }
            
        // if both username and password are empty, then return.
        // Same concept for the enter = true.
        if (username.isEmpty() || password.isEmpty()) {
        	if(enter == true) {
        		JOptionPane.showMessageDialog(this, "Please enter a username and password.");
        	}
        	enter = true;
            return;
        }
            
        // Basically, validate if the user already exists/created an account.
        boolean valid = adminDao.checkIfAdminExists(username, password);
            
        if (valid) {
        	JOptionPane.showMessageDialog(this, "User already exists!");
        } else {
                
            // I just copied this from the AdminDAO.
        	String sql = "INSERT INTO admins(username, password) VALUES (?,?)";
        		
        	try (Connection conn = Database.getConnection(); 
        			PreparedStatement pstmt = conn.prepareStatement(sql)){
        		pstmt.setString(1, username);
        		pstmt.setString(2, password);
        		pstmt.executeUpdate();
        			
        		// Tell the user that the sign up was successful.
        		JOptionPane.showMessageDialog(this, "Sign Up Successful!.");
        	} catch (SQLException e) {
        		e.printStackTrace();
        	}
        		
        	// Prompt the user to return to the log in because the sign up was successful!
        	JOptionPane.showMessageDialog(this, "Please return to Log In!.");
        		
        	// Set the text field and label back to invisible.
            confirmPasswordLabel.setVisible(false);
            repeatPasswordField.setVisible(false);
            	
            return;
        }
    }
}
